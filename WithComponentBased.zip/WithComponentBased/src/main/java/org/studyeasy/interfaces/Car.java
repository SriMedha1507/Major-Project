package org.studyeasy.interfaces;

public interface Car {
	
	String specs();

}
