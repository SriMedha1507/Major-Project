package org.studyeasy;

import org.studyeasy.interfaces.Car;

public class Corolla implements Car{
	
	public String specs() {
		return "Sedan from Toyota";
	}

}
