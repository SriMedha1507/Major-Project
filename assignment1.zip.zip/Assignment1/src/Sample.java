
public class Sample {

	public static void main(String[] args) {
		System.out.println("Hello");
		// TODO Auto-generated method stub

	}

}
