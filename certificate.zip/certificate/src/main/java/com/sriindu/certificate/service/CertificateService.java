package com.sriindu.certificate.service;

import java.util.List;

import com.sriindu.certificate.entity.Certificate;

public interface CertificateService {

	Certificate saveCertificate(Certificate certificate);

	List<Certificate> fetchCertificateList();

	Certificate fetchCertificateById(Long id);

	void deleteCertificateById(Long id);

}
