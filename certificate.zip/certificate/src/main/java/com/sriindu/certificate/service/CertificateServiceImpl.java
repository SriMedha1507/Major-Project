package com.sriindu.certificate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sriindu.certificate.entity.Certificate;
import com.sriindu.certificate.repository.CertificateRepository;

@Service
public class CertificateServiceImpl implements CertificateService{
	
	@Autowired
	CertificateRepository cr;

	@Override
	public Certificate saveCertificate(Certificate certificate) {
		// TODO Auto-generated method stub
		return cr.save(certificate);
	}

	@Override
	public List<Certificate> fetchCertificateList() {
		// TODO Auto-generated method stub
		return cr.findAll();
	}

	@Override
	public Certificate fetchCertificateById(Long id) {
		// TODO Auto-generated method stub
		return cr.findById(id).get();
	}

	@Override
	public void deleteCertificateById(Long id) {
		// TODO Auto-generated method stub
		cr.deleteById(id);
		
	}

}
